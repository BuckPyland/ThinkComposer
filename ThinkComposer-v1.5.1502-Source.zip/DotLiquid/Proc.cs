﻿namespace DotLiquid
{
	public delegate object Proc(Context context);
}